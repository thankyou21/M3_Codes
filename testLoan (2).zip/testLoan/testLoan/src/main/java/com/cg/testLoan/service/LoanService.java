package com.cg.testLoan.service;

import java.util.regex.Pattern;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;

@Component
public class LoanService {
	
	
	public LoanService() {
		super();
		// TODO Auto-generated constructor stub
	}

	public boolean validatePhoneNo(int age)
	{
		String a=Integer.toString(age);
		String pattern="[0-9]{2}";
		if(Pattern.matches(pattern, a))
		{
			return true;
		}
		return false;
	}
}
