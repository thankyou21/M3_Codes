package com.cg.testLoan.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cg.testLoan.entity.Trainer;


public interface TrainerDao extends MongoRepository<Trainer,Integer>
{

}
