package com.cg.testLoan.controller;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.testLoan.dao.EmployeeDao;
import com.cg.testLoan.dao.TrainerDao;
import com.cg.testLoan.entity.Employee;
import com.cg.testLoan.entity.Trainer;
import com.cg.testLoan.service.LoanService;

@RestController
public class LoanController 
{
	@Autowired
	EmployeeDao ed = null;
	
	@Autowired
	TrainerDao td = null;
	
	@Autowired
	LoanService ls = null;
	
	@PostMapping("/insertEmp")
	public String insertPassenger(@RequestBody Employee p)
	{
		if(ls.validatePhoneNo(p.getAge()))
		{
			ed.save(p);
			return "Success";
		}
		else
			return "Failed";
	}
	
	@PostMapping("/insertTra")
	public String insertPassenger(@RequestBody Trainer p)
	{
		td.save(p);
		return "Success";
	}
}
