package com.cg.testLoan.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cg.testLoan.entity.Employee;


public interface EmployeeDao extends MongoRepository<Employee,Integer>
{

}
